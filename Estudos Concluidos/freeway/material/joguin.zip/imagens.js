let imagemDaEstrada;
let imagemDoAtor;
let imagemCarro;
let imagemCarro2;
let imagemCarro3;
let somDaTrilha;
let somColisao;
let somPonto;



function preload(){
  imagemDaEstrada = loadImage("imagens/estrada.png");
  imagemDoAtor = loadImage("imagens/skorpex.png");
  imagemCarro = loadImage("imagens/shala.png");
  imagemCarro2 = loadImage("imagens/massaro.png");
  imagemCarro3 = loadImage("imagens/luciano.png");
  imagemCarro4 = loadImage("imagens/kisota.png");
  imagemCarro5 = loadImage("imagens/abracoke.png");
  imagemCarro6 = loadImage("imagens/romano.png");
  imagemCarros = [imagemCarro, imagemCarro2, imagemCarro3, imagemCarro4, imagemCarro5, imagemCarro6]
  somDaTrilha = loadSound("sons/Girls_Club (mp3cut.net).mp3");
  somColisao = loadSound("sons/colidiu.mp3");
  somPonto = loadSound("sons/marmita.mp3");
}